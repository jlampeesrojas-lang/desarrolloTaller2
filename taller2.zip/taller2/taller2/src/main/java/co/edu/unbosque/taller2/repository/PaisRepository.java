package co.edu.unbosque.taller2.repository;

public class PaisRepository {

}
