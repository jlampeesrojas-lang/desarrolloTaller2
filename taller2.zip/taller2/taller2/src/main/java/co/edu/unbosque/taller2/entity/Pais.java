package co.edu.unbosque.taller2.entity;

public class Pais {

}
